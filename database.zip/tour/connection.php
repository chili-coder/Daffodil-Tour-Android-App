<?php

$host = "localhost";
$user = "sohaghlab_lab";
$password =  "YcYo~iF2PVTF";
$db = "sohaghlab_tour";

$conn = mysqli_connect($host,$user,$password,$db);

if(!$conn)
{
    die("Error in connection " .mysqli_connect_error());
}
else
{
echo" " ;

}

?>